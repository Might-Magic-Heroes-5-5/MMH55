##################################
########## Installation ##########
##################################

1. Extract the contents of this archive in <Game folder> data.
2. Launch the Map Editor
3. You should be able to see new dwellings and their pictures.

##################################
######## Troubleshooting #########
##################################

If you see the dwellings but you dont see the pictures clean the Editor cache.
1. Go to <Game folder>/Editor/IconCache/AdvMapObjectLink/MapObjects/_(AdvMapObjectLink)/Objects-Dwellings
2. Sort for *t.(AdvMapObjectLink) in the search engine and delete all 32 entries.
3. Open the editor and check again.